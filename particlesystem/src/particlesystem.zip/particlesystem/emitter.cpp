//
//  emitter.cpp
//  particlesystem
//
//  Created by Salma Gabot on 2023-03-29.
//

#include <particlesystem/emitter.hpp>
